---
layout: archive
title: "CV"
permalink: /cv/
author_profile: true
redirect_from:
  - /resume
---

My CV can be found [here](../files/Shen_CV.pdf){:target="_blank"}.

*Last updated November 2021*.